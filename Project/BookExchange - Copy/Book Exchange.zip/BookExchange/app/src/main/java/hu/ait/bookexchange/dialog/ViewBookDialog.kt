package hu.ait.bookexchange

import android.app.Dialog
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.provider.MediaStore
import android.view.View
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import androidx.fragment.app.DialogFragment
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import hu.ait.bookexchange.OwnedBookActivity.Companion.CAMERA_REQUEST_CODE
import hu.ait.bookexchange.OwnedBookActivity.Companion.KEY_BOOK_EDIT
import hu.ait.bookexchange.OwnedBookActivity.Companion.PERMISSION_REQUEST_CODE
import hu.ait.bookexchange.data.Book
import hu.ait.bookexchange.databinding.BookDialogBinding
import java.util.*

class ViewBookDialog: DialogFragment() {
    lateinit var bookDialogBinding: BookDialogBinding
    lateinit var bookView: Book

    override fun onAttach(context: Context) {
        super.onAttach(context)
    }

    override fun onCreateDialog(savedInstanceState: Bundle?): Dialog {
        val dialogBuilder = AlertDialog.Builder(requireContext())
        dialogBuilder.setTitle("Book Details")

        bookDialogBinding = BookDialogBinding.inflate(layoutInflater)
        dialogBuilder.setView(bookDialogBinding.root)

        val conditionAdapter = ArrayAdapter.createFromResource(
            requireActivity(),
            R.array.condition_array,
            android.R.layout.simple_spinner_item)

        conditionAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )
        bookDialogBinding.spinnerConditions.adapter = conditionAdapter

        bookView = requireArguments().getSerializable(
                    ClaimedBookActivity.KEY_BOOK_VIEW) as Book

        if (bookView.imgUrl.isNotEmpty()) {
                Glide.with(requireActivity()).load(bookView.imgUrl).into(bookDialogBinding.ivBook)
        }

            bookDialogBinding.etTitle.setText(bookView.title)
            bookDialogBinding.etPrice.setText(bookView.price.toString())
            bookDialogBinding.etAuthor.setText(bookView.author)
            bookDialogBinding.spinnerConditions.setSelection(bookView.condition)

        bookDialogBinding.etTitle.isEnabled = false
        bookDialogBinding.etPrice.isEnabled = false
        bookDialogBinding.etAuthor.isEnabled = false
        bookDialogBinding.spinnerConditions.isEnabled = false

        dialogBuilder.setNegativeButton("Cancel") {
                dialog, which ->
        }

        return dialogBuilder.create()
    }
}