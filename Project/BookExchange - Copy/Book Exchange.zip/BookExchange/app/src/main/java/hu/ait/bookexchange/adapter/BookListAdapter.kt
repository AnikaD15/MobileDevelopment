package hu.ait.bookexchange.adapter

import android.content.Context
import android.view.View
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.google.android.material.snackbar.Snackbar
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import hu.ait.bookexchange.BookListActivity
import hu.ait.bookexchange.OwnedBookActivity
import hu.ait.bookexchange.data.Book
import hu.ait.bookexchange.databinding.BookItemBinding
import java.sql.Time
import java.util.*

class BookListAdapter : RecyclerView.Adapter<BookListAdapter.ViewHolder>  {
    lateinit var context: Context
    lateinit var currUserId: String
    var  bookList = mutableListOf<Book>()
    var  bookKeys = mutableListOf<String>()

    constructor(context: Context, uid: String) : super() {
        this.context = context
        this.currUserId = uid
    }

    override fun getItemCount(): Int {
        return bookList.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = BookItemBinding.inflate((context as BookListActivity).layoutInflater,
            parent, false)

        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val book = bookList[holder.adapterPosition]
        holder.bind(book)

        if (book.imgUrl.isNotEmpty()) {
            Glide.with(context as BookListActivity).load(book.imgUrl).into(holder.binding.ivBook)
        }

        holder.binding.btnClaim.setOnClickListener {
            if(!bookList[holder.adapterPosition].isClaimed){
                claimBook(holder.adapterPosition, currUserId)
            }
        }
    }

    private fun claimBook(index: Int, currUserId: String) {
        // update book in database
        bookList[index].isClaimed = true
        bookList[index].claimedBy = currUserId
        notifyItemChanged(index)
        val bookCollection = FirebaseFirestore.getInstance().collection(BookListActivity.COLLECTION_BOOKS)
        bookCollection.document(bookKeys[index]).set(bookList[index])

//        val calendar = Calendar.getInstance()
//        calendar.add(Calendar.DATE, CLAIM_PERIOD)
//        bookList[index].claimEndDate = calendar.time
    }

    private fun removeBook(index: Int) {
        FirebaseFirestore.getInstance().collection(BookListActivity.COLLECTION_BOOKS).document(
            bookKeys[index]
        ).delete()

        bookList.removeAt(index)
        bookKeys.removeAt(index)
        notifyItemRemoved(index)
    }

    fun removeBookByKey(key: String) {
        val index = bookKeys.indexOf(key)
        if (index != -1) {
            bookList.removeAt(index)
            bookKeys.removeAt(index)
            notifyItemRemoved(index)
        }
    }

    fun addBook(book:Book, key:String){
        bookList.add(book)
        bookKeys.add(key)
        notifyItemInserted(bookList.lastIndex)
    }

    fun updateBook(book:Book, key:String){
        var index = bookKeys.indexOf(key)
        bookList[index] = book
        notifyItemChanged(index)

        val bookCollection = FirebaseFirestore.getInstance().collection(BookListActivity.COLLECTION_BOOKS)
        bookCollection.document(bookKeys[index]).set(bookList[index])
    }

    inner class ViewHolder(var binding: BookItemBinding) : RecyclerView.ViewHolder(binding.root){
        fun bind(book: Book){
            binding.tvTitle.text = book.title
            binding.tvAuthor.text = book.author
            binding.tvPrice.text = book.price.toString()
        }
    }
}