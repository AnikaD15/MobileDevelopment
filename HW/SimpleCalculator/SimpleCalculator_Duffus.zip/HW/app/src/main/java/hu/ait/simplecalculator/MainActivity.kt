// Anika Duffus
// optional HW #1

package hu.ait.simplecalculator

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import hu.ait.simplecalculator.databinding.ActivityMainBinding
import java.util.*

class MainActivity : AppCompatActivity() {

    lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnPlus.setOnClickListener {
            var num1 = binding.num1.text.toString()
            var num2 = binding.num2.text.toString()
            if(num1 != "" && num2 != ""){
                var sum = num1.toInt() + num2.toInt()
                binding.tvResult.text = "Result: $sum"
            }
            else{
                binding.tvResult.text = "Enter 2 operands and try again."
            }
        }

        binding.btnMinus.setOnClickListener {
            var num1 = binding.num1.text.toString()
            var num2 = binding.num2.text.toString()
            if(num1 != "" && num2 != ""){
                var sum = num1.toInt() - num2.toInt()
                binding.tvResult.text = "Result: $sum"
            }
            else{
                binding.tvResult.text = "Enter 2 operands and try again."
            }
        }
    }
}

